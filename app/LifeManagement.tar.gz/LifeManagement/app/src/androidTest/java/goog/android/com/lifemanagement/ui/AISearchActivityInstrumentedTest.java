package goog.android.com.lifemanagement.ui;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.widget.TextView;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import goog.android.com.lifemanagement.R;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.matcher.ViewMatchers.withId;

/**
 * AISearchActivity Unit test by espresso.
 */
@RunWith(AndroidJUnit4.class)
public class AISearchActivityInstrumentedTest {
    private static final String QUERY_STRING = "List the expense this year";

    @Rule
    public final ActivityTestRule<AISearchActivity> mActivityRule =
            new ActivityTestRule<>(AISearchActivity.class);

    @Test
    public void testClickSendButtonWithQueryString() throws InterruptedException {
        // Type text and then press the button.
        onView(withId(R.id.textQuery)).perform(typeText(QUERY_STRING));
        onView(withId(R.id.buttonSend)).perform(click());

        Thread.sleep(5000);

        // Check if result view have any string
        TextView resultButtonView = (TextView)mActivityRule.getActivity().findViewById(R.id.resultTextView);
        Assert.assertTrue(resultButtonView.getText().length()>0);

    }

}