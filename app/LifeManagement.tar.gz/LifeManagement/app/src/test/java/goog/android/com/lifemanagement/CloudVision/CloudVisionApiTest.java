package goog.android.com.lifemanagement.CloudVision;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CloudVisionApiTest {

    private CloudVisionApi cloudVisionApi;

    @Before
    public void setUp() throws Exception {
        cloudVisionApi = CloudVisionApi.getInstance(null, null);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getCloudVisioAPIResult() {
        //TODO: not yet implement
    }

    @Test
    public void startCloudVisionService() {
        cloudVisionApi.startCloudVisionService(null);
        //TODO: not yet implement
    }

    @Test
    public void analyzeImagesByCloudVision() {
        //TODO: not yet implement
    }
}