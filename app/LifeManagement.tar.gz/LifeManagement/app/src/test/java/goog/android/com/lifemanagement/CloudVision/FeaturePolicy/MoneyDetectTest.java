/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package goog.android.com.lifemanagement.CloudVision.FeaturePolicy;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;

import static org.junit.Assert.assertTrue;

@RunWith(Parameterized.class)
public class MoneyDetectTest {
    private ReceiptFeatureDetect receiptFeatureDetect;

    @Parameter(0)
    public String m1;
    @Parameter(1)
    public boolean m2;
    @Parameters
    public static Collection<Object[]> data() {
        Object[][] data = new Object[][] {
                {"23.09", true},
                {"11.22", true},
                {"29", true},
                {"1120", true},
                {"12.99", true},
                {"12938", true}
        };
        return Arrays.asList(data);
    }

    @Before
    public void setUp() throws Exception {
        receiptFeatureDetect = new ReceiptFeatureDetect();
    }

    @After
    public void tearDown() throws Exception {
        receiptFeatureDetect = null;
    }

    @Test
    public void testParseMoney_by_Various_MoneyFormat() {
        Optional<Float> moneyop = receiptFeatureDetect.parseMoney(m1);

        assertTrue("money format wrong", (m2 == moneyop.isPresent()));
    }
}