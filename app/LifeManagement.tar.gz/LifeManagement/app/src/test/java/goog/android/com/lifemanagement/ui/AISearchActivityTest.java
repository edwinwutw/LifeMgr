/**
 * Copyright 2018, The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package goog.android.com.lifemanagement.ui;

import android.content.Context;
import android.widget.TextView;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;

import goog.android.com.lifemanagement.BuildConfig;
import goog.android.com.lifemanagement.R;

/**
 * unit test for AISearchActivity
 */
@Config(constants = BuildConfig.class)
@RunWith(RobolectricTestRunner.class)
public class AISearchActivityTest {
    private static final String QUERY_STRING = "Invalid Query";

    /** Click send button, check the result view should hint user  query string shouldn't be empty.*/
    @Test
    public void testClickSendButtonWithoutAnyQuery(){
        AISearchActivity searchActivity = Robolectric.setupActivity(AISearchActivity.class);
        Assert.assertNotNull(searchActivity);

        // perform click send button.
        searchActivity.findViewById(R.id.buttonSend).performClick();
        TextView resultButtonView = (TextView)searchActivity.findViewById(R.id.resultTextView);

        final Context context = RuntimeEnvironment.application;
        // check if result view have warning string
        Assert.assertEquals(context.getString(R.string.non_empty_query),
                resultButtonView.getText().toString());
    }

    /** Click send button with specific query string, and check if feedback from Dialogflow is empty or not */
    @Test
    public void testClickSendButtonWithQueryString(){
        AISearchActivity searchActivity = Robolectric.setupActivity(AISearchActivity.class);
        Assert.assertNotNull(searchActivity);

        TextView queryTextView = (TextView)searchActivity.findViewById(R.id.textQuery);
        queryTextView.setText(QUERY_STRING);

        // perform click send button.
        searchActivity.findViewById(R.id.buttonSend).performClick();
        TextView resultButtonView = (TextView)searchActivity.findViewById(R.id.resultTextView);

        // check if result view have warning string
        Assert.assertTrue(resultButtonView.getText().length()>0);
    }

    /** Click CLEAR button, check the result view should be empty.*/
    @Test
    public void testClickClearButton(){
        AISearchActivity searchActivity = Robolectric.setupActivity(AISearchActivity.class);
        Assert.assertNotNull(searchActivity);

        TextView queryTextView = (TextView)searchActivity.findViewById(R.id.textQuery);
        queryTextView.setText(QUERY_STRING);

        // Perform click CLEAR button.
        searchActivity.findViewById(R.id.buttonClear).performClick();
        TextView resultButtonView = (TextView)searchActivity.findViewById(R.id.resultTextView);

        // Check if result view show the query string is empty
        Assert.assertTrue(resultButtonView.getText().length() == 0);
    }
}