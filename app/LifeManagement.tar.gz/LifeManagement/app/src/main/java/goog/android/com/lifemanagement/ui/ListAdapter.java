/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package goog.android.com.lifemanagement.ui;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.text.style.SuperscriptSpan;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.time.format.DateTimeFormatter;
import java.util.List;

import goog.android.com.lifemanagement.R;
import goog.android.com.lifemanagement.data.database.Event;
import goog.android.com.lifemanagement.databinding.ListItemBinding;


public class ListAdapter extends RecyclerView.Adapter<ListAdapter.EventViewHolder> {
    List<? extends Event> mEventList;

    @Nullable
    private final ItemClickCallback mItemClickCallback;

    public ListAdapter(@Nullable ItemClickCallback clickCallback) {
        mItemClickCallback = clickCallback;
    }

    public void setEventList(final List<? extends Event> eventList) {
        if (mEventList == null) {
            mEventList = eventList;
            notifyItemRangeInserted(0, eventList.size());
        } else {
            DiffUtil.DiffResult result = DiffUtil.calculateDiff(new DiffUtil.Callback() {
                @Override
                public int getOldListSize() {
                    return mEventList.size();
                }

                @Override
                public int getNewListSize() {
                    return eventList.size();
                }

                @Override
                public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
                    return mEventList.get(oldItemPosition).getId() ==
                            eventList.get(newItemPosition).getId();
                }

                @Override
                public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
                    Event newEvent = eventList.get(newItemPosition);
                    Event oldEvent = mEventList.get(oldItemPosition);
                    return newEvent.getId() == oldEvent.getId();
                }
            });
            mEventList = eventList;
            result.dispatchUpdatesTo(this);
        }
    }

    @Override
    public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ListItemBinding binding = DataBindingUtil
                .inflate(LayoutInflater.from(parent.getContext()), R.layout.list_item,
                        parent, false);
        binding.setCallback(mItemClickCallback);
        return new EventViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(EventViewHolder holder, int position) {
        holder.binding.setEvent(mEventList.get(position));

        DateTimeFormatter df = DateTimeFormatter.ofPattern("MMM d");
        if (mEventList.get(position).getDate() != null) {

            String lineNo = position + ". ";
            SpannableString sp = new SpannableString(lineNo
                    + mEventList.get(position).getDate().format(df));
            sp.setSpan(new SuperscriptSpan(), 0, lineNo.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp.setSpan(new RelativeSizeSpan(0.5f), 0, lineNo.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            holder.binding.date.setText(sp);
        }

        Context context = holder.binding.thumb.getContext();
        Uri uri = Uri.fromFile(new File(mEventList.get(position).getAvatarPath()));
        Picasso.with(context)
                .load(uri)
                .fit()
                .centerCrop()
                .into(holder.binding.thumb);

        holder.binding.executePendingBindings();
    }

    @Override
    public int getItemCount() {
        return mEventList == null ? 0 : mEventList.size();
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {

        final ListItemBinding binding;

        public EventViewHolder(ListItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
