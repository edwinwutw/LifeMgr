package goog.android.com.lifemanagement.utils;

import android.location.Location;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

/**
 * Implementation of density-based clustering algorithm DBSCAN.
 *
 */

public class DBSCANClusterer<V> {
    /**
     * maximum distance of values to be considered as cluster
     */
    private double epsilon = 1f;
    /**
     * minimum number of members to consider cluster
     */
    private int minimumNumberOfClusterMembers = 2;

    /**
     * internal list of input values to be clustered
     */
    private ArrayList<V> inputValues = null;
    /**
     * index maintaining visited points
     */
    private HashSet<V> visitedPoints = new HashSet<V>();

    /**
     * Creates a DBSCAN clusterer instance.
     *
     * @param inputValues    Input values to be clustered
     * @param minNumElements Minimum number of elements to constitute cluster
     * @param maxDistance    Maximum distance of elements to consider clustered
     * @throws DBScan_ClusterException
     */
    public DBSCANClusterer(final Collection<V> inputValues, int minNumElements, double maxDistance) throws DBScan_ClusterException {
        setInputValues(inputValues);
        setMinimalNumberOfMembers(minNumElements);
        setMaximalDistance(maxDistance);
    }

    public void setInputValues(final Collection<V> collection) throws DBScan_ClusterException {
        if (collection == null) {
            throw new DBScan_ClusterException("DBSCAN: List of input values is null.");
        }
        this.inputValues = new ArrayList<V>(collection);
    }

    public void setMinimalNumberOfMembers(final int minimalNumberOfMembers) {
        this.minimumNumberOfClusterMembers = minimalNumberOfMembers;
    }

    public void setMaximalDistance(final double maximalDistance) {
        this.epsilon = maximalDistance;
    }

    /**
     * Determines the neighbours of a given input value.
     *
     * @param inputValue Input value for which neighbours are to be determined
     * @return list of neighbours
     * @throws DBScan_ClusterException
     */
    private ArrayList<V> getNeighbours(final V inputValue) throws DBScan_ClusterException {
        ArrayList<V> neighbours = new ArrayList<V>();
        for (int i = 0; i < inputValues.size(); i++) {
            V candidate = inputValues.get(i);
            if (calculate_Distance((Point) inputValue, (Point) candidate) <= epsilon) {
                neighbours.add(candidate);
            }
        }
        return neighbours;
    }

    /**
     * Merges the elements of the right collection to the left one and returns
     * the combination.
     *
     * @param neighbours1 left collection
     * @param neighbours2 right collection
     * @return Modified left collection
     */
    private ArrayList<V> mergeRightToLeftCollection(final ArrayList<V> neighbours1,
                                                    final ArrayList<V> neighbours2) {
        for (int i = 0; i < neighbours2.size(); i++) {
            V tempPt = neighbours2.get(i);
            if (!neighbours1.contains(tempPt)) {
                neighbours1.add(tempPt);
            }
        }
        return neighbours1;
    }

    /**
     * Applies the clustering and returns a collection of clusters (i.e. a list
     * of lists of the respective cluster members).
     *
     * @return
     * @throws DBScan_ClusterException
     */
    public ArrayList<ArrayList<V>> perform() throws DBScan_ClusterException {
        if (inputValues == null) {
            throw new DBScan_ClusterException("DBScan: List of input is null.");
        }
        if (inputValues.isEmpty()) {
            throw new DBScan_ClusterException("DBScan: List of input is empty.");
        }
        if (inputValues.size() < 2) {
            throw new DBScan_ClusterException("DBScan: Less than two input cannot be clustered. Number of input values: " + inputValues.size());
        }
        if (epsilon < 0) {
            throw new DBScan_ClusterException("DBSCan: Maximum distance of input values cannot be negative. Current value: " + epsilon);
        }
        if (minimumNumberOfClusterMembers < 2) {
            throw new DBScan_ClusterException("DBSCan: Less than 2 members don't make sense. Current value: " + minimumNumberOfClusterMembers);
        }
        ArrayList<ArrayList<V>> resultList = new ArrayList<ArrayList<V>>();
        visitedPoints.clear();
        ArrayList<V> neighbours;
        int index = 0;
        while (inputValues.size() > index) {
            V p = inputValues.get(index);
            if (!visitedPoints.contains(p)) {
                visitedPoints.add(p);
                neighbours = getNeighbours(p);
                if (neighbours.size() >= minimumNumberOfClusterMembers) {
                    int ind = 0;
                    while (neighbours.size() > ind) {
                        V r = neighbours.get(ind);
                        if (!visitedPoints.contains(r)) {
                            visitedPoints.add(r);
                            ArrayList<V> individualNeighbours = getNeighbours(r);
                            if (individualNeighbours.size() >= minimumNumberOfClusterMembers) {
                                neighbours = mergeRightToLeftCollection(
                                        neighbours,
                                        individualNeighbours);
                            }
                        }
                        ind++;
                    }
                    resultList.add(neighbours);
                }
            }
            index++;
        }
        return resultList;
    }

    public double calculate_Distance(Point p1, Point p2) {

        float[] results=new float[1];
        Location.distanceBetween((Double) p1.getX(), (Double) p1.getY(), (Double) p2.getX(), (Double) p2.getY(), results);
        return results[0];

    }
}
