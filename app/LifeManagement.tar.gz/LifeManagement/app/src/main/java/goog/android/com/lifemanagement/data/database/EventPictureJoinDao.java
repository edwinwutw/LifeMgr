package goog.android.com.lifemanagement.data.database;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.RoomWarnings;

import java.util.List;

/**
 * Created by edwinwu on 2018/3/27.
 */
@Dao
public interface EventPictureJoinDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(EventPictureJoin... eventPictures);

    @Delete
    void delete(EventPictureJoin... eventPictures);

    @Query("DELETE FROM event_picture")
    void deleteAll();

    @SuppressWarnings(RoomWarnings.CURSOR_MISMATCH)
    @Query("SELECT * FROM picturerepo INNER JOIN event_picture ON " +
            "picturerepo.id=event_picture.pictureId WHERE event_picture.eventId=:eventId")
    LiveData<List<PictureRepo>> getEventPictures(final int eventId);

    @SuppressWarnings(RoomWarnings.CURSOR_MISMATCH)
    @Query("SELECT * FROM picturerepo INNER JOIN event_picture ON " +
            "picturerepo.id=event_picture.pictureId WHERE event_picture.eventId=:eventId")
    List<PictureRepo> getEventPicturesImmediately(final int eventId);
}
