/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License
 */

package goog.android.com.lifemanagement.ui;

import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;

import goog.android.com.lifemanagement.R;
import goog.android.com.lifemanagement.data.database.PictureRepo;
import goog.android.com.lifemanagement.databinding.DetailFragmentBinding;
import goog.android.com.lifemanagement.utils.DBSCANClusterer;
import goog.android.com.lifemanagement.utils.DBScan_ClusterException;
import goog.android.com.lifemanagement.utils.Point;
import goog.android.com.lifemanagement.viewmodel.DetailViewModel;

import static junit.framework.Assert.assertEquals;

/**
 * A placeholder fragment containing a simple view.
 */
public class DetailFragment extends Fragment implements OnMapReadyCallback {
    private static final String TAG = "DetailViewModel";
    private static final String KEY_EVENT_ID = "event_id";
    private static final String KEY_LAT = "event_latitude";
    private static final String KEY_LNG = "event_longitude";
    private static final int GRID_NUMBER_OF_COLUMNS = 6;
    private static final int MIN_NUMBER_ELEMENTS = 2;
    private static final int MAX_DISTANCE = 200000;

    private DetailFragmentBinding mBinding;

    private PicRecyclerAdapter adapter;

    private MapView mMapView;

    private GoogleMap mGoogleMap;

    private DetailViewModel mDetailViewModel;
    private int mId;

    private double mLat;
    private double mLng;

    private MarkerOptions mOptions = new MarkerOptions();
    private ArrayList<LatLng> mLatlngs = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate this data binding layout
        mBinding = DataBindingUtil.inflate(inflater, R.layout.detail_fragment, container, false);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mMapView = (MapView) view.findViewById(R.id.mapView);
        mMapView.onCreate(savedInstanceState);
        mMapView.onResume();
        mMapView.getMapAsync(this);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mId = getArguments().getInt(KEY_EVENT_ID);

        DetailViewModel.Factory factory =
                new DetailViewModel.Factory(getActivity().getApplication(), mId);

        final DetailViewModel model =
                ViewModelProviders.of(this, factory).get(DetailViewModel.class);

        mDetailViewModel = model;

        mBinding.setDetailViewModel(model);

        subscribeToModel(model);

        //for test DB Scan
        DBSCANClusterer<Point> clusterer = null;
        ArrayList<Point> input = new ArrayList<>();
        Point Nvalues = new Point();
        Nvalues.setX(22.00);
        Nvalues.setY(33.00);
        input.add(Nvalues);

        Point Nvalues1 = new Point();
        Nvalues1.setX(22.00);
        Nvalues1.setY(34.00);
        input.add(Nvalues1);

        Point Nvalues2 = new Point();
        Nvalues2.setX(77.00);
        Nvalues2.setY(88.00);
        input.add(Nvalues2);

        Point Nvalues3 = new Point();
        Nvalues3.setX(77.00);
        Nvalues3.setY(89.00);
        input.add(Nvalues3);

        Point Nvalues4 = new Point();
        Nvalues4.setX(77.00);
        Nvalues4.setY(90.00);
        input.add(Nvalues4);

        try {
            clusterer = new DBSCANClusterer<Point>(input, MIN_NUMBER_ELEMENTS, MAX_DISTANCE);
            clusterer.perform();
        } catch (DBScan_ClusterException e1) {
            assertEquals("Too few input values error", "DBSCAN: Less than two input " +
                    "values cannot be clustered. Number of input values: 1", e1.getMessage());
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;
        mLat = getArguments().getDouble(KEY_LAT);
        mLng = getArguments().getDouble(KEY_LNG);
        if (mLat == 0 && mLng == 0) {
            Log.d(TAG, "set defalt pos>");
            LatLng defaultPos = new LatLng(22.988, 120.192);
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultPos, 13));
            return;
        }
        LatLng augsburg = new LatLng(mLat, mLng);
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(augsburg, 13));
        googleMap.addMarker(new MarkerOptions()
                .title("Augsburg Zoo")
                .snippet("Der coolste Zoo der Welt")
                .position(augsburg));
    }

    private void subscribeToModel(final DetailViewModel model) {
        // Observe event data
        model.getEventsDetail().observe(this, eventEntity -> {
            mBinding.setEvent(eventEntity);

            new AsyncTask<Void, Void, List<PictureRepo>>() {
                @Override
                protected List<PictureRepo> doInBackground(Void... params) {
                    List<PictureRepo> pictureRepos = mDetailViewModel.getEventPicturesImmediately(mId);
                    return pictureRepos;
                }

                @Override
                protected void onPostExecute(List<PictureRepo> PictureRepos) {
                    boolean findValidPos = false;
                    LatLng cameraPos = null;

                    if (PictureRepos != null) {
                        ArrayList<String> listOfAllImages = new ArrayList<String>();
                        for (int i = 0; i < PictureRepos.size(); i++) {
                            listOfAllImages.add(PictureRepos.get(i).getImagePath());
                            double lat = PictureRepos.get(i).getExifLatitude();
                            double lng = PictureRepos.get(i).getExifLongitude();
                            if (lat != 0 && lng != 0) {
                                if (!findValidPos) {
                                    findValidPos = true;
                                    cameraPos = new LatLng(lat, lng);
                                }
                                mLatlngs.add(new LatLng(lat, lng));
                            }
                        }
                        // set up the RecyclerView
                        RecyclerView recyclerView = getActivity().findViewById(R.id.rvNumbers);
                        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), GRID_NUMBER_OF_COLUMNS));
                        adapter = new PicRecyclerAdapter(getContext(), listOfAllImages);
                        recyclerView.setAdapter(adapter);

                        for (LatLng point : mLatlngs) {
                            mOptions.position(point);
                            mOptions.title("someTitle");
                            mOptions.snippet("someDesc");
                            mGoogleMap.addMarker(mOptions);
                        }
                        if (!findValidPos) {
                            cameraPos = new LatLng(22.988, 120.192);
                        }
                        mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(cameraPos, 13));
                        Log.d(TAG, "map update done>");

                    }
                }
            }.execute();
        });
    }


    /**
     * Creates detail fragment for specific event ID
     */
    public static DetailFragment forEvent(int eventId, double lan, double lng) {
        DetailFragment fragment = new DetailFragment();
        Bundle args = new Bundle();
        args.putInt(KEY_EVENT_ID, eventId);
        args.putDouble(KEY_LAT, lan);
        args.putDouble(KEY_LNG, lng);
        fragment.setArguments(args);
        return fragment;
    }

}