package goog.android.com.lifemanagement.CloudVision;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.vision.v1.Vision;
import com.google.api.services.vision.v1.VisionRequestInitializer;
import com.google.api.services.vision.v1.model.AnnotateImageRequest;
import com.google.api.services.vision.v1.model.AnnotateImageResponse;
import com.google.api.services.vision.v1.model.BatchAnnotateImagesRequest;
import com.google.api.services.vision.v1.model.BatchAnnotateImagesResponse;
import com.google.api.services.vision.v1.model.Feature;
import com.google.api.services.vision.v1.model.Image;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import goog.android.com.lifemanagement.AppExecutors;
import goog.android.com.lifemanagement.BuildConfig;
import goog.android.com.lifemanagement.CloudVision.FeaturePolicy.FaceFeatureDetect;
import goog.android.com.lifemanagement.CloudVision.FeaturePolicy.FeatureType;
import goog.android.com.lifemanagement.CloudVision.FeaturePolicy.LabelFeatureDetect;
import goog.android.com.lifemanagement.CloudVision.FeaturePolicy.ReceiptFeatureDetect;
import goog.android.com.lifemanagement.service.ClusterIntentService;

/**
 * Created by edwinwu on 2018/4/03
 */

public class CloudVisionApi {
    private static final String TAG = CloudVisionApi.class.getSimpleName();

    // For Singleton instantiation
    private static final Object LOCK = new Object();
    private static CloudVisionApi sInstance;

    private final Context mContext;

    private final AppExecutors mExecutors;

    private static final String CLOUD_VISION_API_KEY = BuildConfig.API_KEY;
    private static final String ANDROID_CERT_HEADER = "X-Android-Cert";
    private static final String ANDROID_PACKAGE_HEADER = "X-Android-Package";
    private static final int MAX_DIMENSION = 1200;

    // contentvalues key
    public final static String CONTENTVALUE_PICTUREID_KEY   = "pictureid"; // room table picturerepo primary id
    public final static String CONTENTVALUE_CLOUDVISION_KEY = "senttocloudvision";
    // key to notify all images are done with CloudVision
    public final static String CONTENTVALUE_DONECLOUDVISION_KEY   = "doneCloudVision";

    // result returned from CloudVision after done and notify to save the result to database
    private final MutableLiveData<List<ContentValues>> mCloudVisioAPIResult = new MutableLiveData<>();
    public LiveData<List<ContentValues>> getCloudVisioAPIResult() {
        return mCloudVisioAPIResult;
    }

    private CloudVisionApi(Context context, AppExecutors executors) {
        mContext = context;
        mExecutors = executors;
    }

    /**
     * Get the singleton for this class
     */
    public static CloudVisionApi getInstance(Context contex, AppExecutors executors) {
        //Log.d(TAG, "Getting the CloudVisionApi");
        if (sInstance == null) {
            synchronized (LOCK) {
                sInstance = new CloudVisionApi(contex, executors);
                Log.d(TAG, "Made new CloudVisionApi");
            }
        }
        return sInstance;
    }
    public void startCloudVisionService(HashMap<Integer, String> pictureRepoMap) {
        Intent intentCloudVision = new Intent(mContext, ClusterIntentService.class);
        intentCloudVision.putExtra(ClusterIntentService.PARAM_IN_SERVICE,
                ClusterIntentService.CLOUDVISION_PARAM);
        Bundle extras = new Bundle();
        extras.putSerializable("HashMap", pictureRepoMap);
        intentCloudVision.putExtras(extras);
        mContext.startService(intentCloudVision);
        Log.d(TAG, "Service created:" + ClusterIntentService.CLOUDVISION_PARAM);
    }

    private static final int CV_GROUP_IMG_SIZE = 16;
    /**
     *  send image data to cloudvision and analyze; this function call must be called in a thread or intentservice
     */
    public void analyzeImagesByCloudVision(Context context, HashMap<Integer, String> pictureMap) {
        if (pictureMap == null) {
            Log.d(TAG, "input parameter null");
            return;
        }

        Log.d(TAG, "--Start handling CloudVision API");
        // group send the images to CloudVision smartly to prevent
        //   1. 10M payload limit size
        //   2. large bitmap data causes OOM
        // Tbd, currently we send by size of CV_GROUP_IMG_SIZE, need enhance here
        List<ContentValues> listContentValues;
        List<Integer> pictureIds = new ArrayList<>();
        List<Bitmap> bitmaps = new ArrayList<>();
        int totaladd = 0;
        int add = 0;
        boolean errorWhileCloudVision = false;
        for (Map.Entry<Integer, String> entry : pictureMap.entrySet()) {
            try {
                int pictureId = entry.getKey().intValue();
                String imgPath = entry.getValue();

                // scale the image to save on bandwidth
                Bitmap bitmap =
                        scaleBitmapDown(
                                BitmapFactory.decodeStream(
                                        context.getContentResolver().openInputStream(Uri.fromFile(new File(imgPath)))),
                                MAX_DIMENSION);

                bitmaps.add(bitmap);
                pictureIds.add(pictureId);
                add++;
                totaladd++;

                if (add == CV_GROUP_IMG_SIZE) {
                    Log.d(TAG, "----total images add = " + totaladd);

                    Log.d(TAG, "----group collected done and send cloudvision");

                    Log.d(TAG, "------start call CloudVision - imageNo=" + bitmaps.size());
                    listContentValues = callCloudVision(bitmaps);
                    // Tbd; enhance here for room pictureId
                    if (listContentValues != null) {
                        for (int i = 0; i < listContentValues.size(); i++)
                            listContentValues.get(i).put(CONTENTVALUE_PICTUREID_KEY, pictureIds.get(i));
                        mCloudVisioAPIResult.postValue(listContentValues);
                        Log.d(TAG, "------postValue result");
                    } else
                        errorWhileCloudVision = true; // null means something when wrong calling CloudVision

                    pictureIds.clear();
                    bitmaps.clear();
                    add = 0;
                } else {
                    Log.d(TAG, "----group collecting...add = " + add);
                }
            } catch(IOException e){
                Log.d(TAG, "image failed because " + e.getMessage());
            } catch(OutOfMemoryError e){
                Log.d(TAG, "image failed because " + e.getMessage());
            }
        }
        // final send the rest
        if (bitmaps.size() != 0) {
            Log.d(TAG, "----total images add = " + totaladd);

            Log.d(TAG, "----group collected done and send cloudvision*");

            Log.d(TAG, "------start call CloudVision - imageNo=" + bitmaps.size());

            listContentValues = callCloudVision(bitmaps);
            // Tbd; enhance here for room pictureId
            if (listContentValues != null) {
                for (int i = 0; i < listContentValues.size(); i++)
                    listContentValues.get(i).put(CONTENTVALUE_PICTUREID_KEY, pictureIds.get(i));
                mCloudVisioAPIResult.postValue(listContentValues);
                Log.d(TAG, "------postValue result");
            } else
                errorWhileCloudVision = true; // null means something wrong when calling CloudVision
        }

        // if one time error back when calling CloudVision; then we don't callback the done key
        if (errorWhileCloudVision) {
            Log.d(TAG, "----error returning from CloudVision API; ignore notify back");
        } else {
            Log.d(TAG, "----succeed returning from CloudVision API; notify back");
            // notify back by reusing List<ContentValues> with a true key CONTENTVALUE_DONECLOUDVISION_KEY
            mCloudVisioAPIResult.postValue(new ArrayList<ContentValues>() {{
                ContentValues cv = new ContentValues();
                cv.put(CONTENTVALUE_DONECLOUDVISION_KEY, true);
                add(cv);
            }});
        }
        Log.d(TAG, "--End handling CloudVision API");
    }

    private List<ContentValues> callCloudVision(final List<Bitmap> bitmaps) {
        if (bitmaps == null) return null;

        int bitmapSize = bitmaps.size();

        try {
            Log.d(TAG, "prepare annotation request");
            List<FeatureType> featureTypeList = provideFeatureTypeList();
            Vision.Images.Annotate annotate = prepareAnnotationRequest(bitmaps, featureTypeList);

            Log.d(TAG, "created Cloud Vision request object, sending request");
            BatchAnnotateImagesResponse response = annotate.execute();

            List<ContentValues> listContentValues = new ArrayList<>(bitmapSize);
            List<AnnotateImageResponse> listAIR = response.getResponses();
            int responseSize = listAIR.size();
            Log.d(TAG, "picture number = " + bitmapSize + ", response number = " + responseSize);
            for (AnnotateImageResponse annotateImageResponse : listAIR) {
                ContentValues contentValues = new ContentValues();
                if (annotateImageResponse != null) {
                    contentValues.put(CONTENTVALUE_CLOUDVISION_KEY, true);
                    for (FeatureType featureType : featureTypeList) {
                        ContentValues cvs = featureType.detectResult(annotateImageResponse);
                        if (cvs.size() != 0) {
                            contentValues.putAll(cvs);
                        }
                    }
                }
                listContentValues.add(contentValues);
            }

            Log.d(TAG, "Cloud Vision finish response");
            return listContentValues;
        } catch (GoogleJsonResponseException e) {
            Log.d(TAG, "failed to make API request because " + e.getContent());
        } catch (IOException e) {
            Log.d(TAG, "failed to make API request because of other IOException " +
                    e.getMessage());
        }

        return null;
    }

    private List<FeatureType> provideFeatureTypeList() {
        List<FeatureType> featureTypeList = new ArrayList<FeatureType>() {
            {
                LabelFeatureDetect labelFeatureDetect = new LabelFeatureDetect();
                add(labelFeatureDetect);

                FaceFeatureDetect faceFeatureDetect = new FaceFeatureDetect();
                add(faceFeatureDetect);

                ReceiptFeatureDetect receiptFeatureDetect = new ReceiptFeatureDetect();
                add(receiptFeatureDetect);
            }
        };

        return featureTypeList;
    }

    private Vision.Images.Annotate prepareAnnotationRequest(List<Bitmap> bitmaps,
                                                            List<FeatureType> featureTypeList) throws IOException {
        HttpTransport httpTransport = AndroidHttp.newCompatibleTransport();
        JsonFactory jsonFactory = GsonFactory.getDefaultInstance();

        VisionRequestInitializer requestInitializer =
                new VisionRequestInitializer(CLOUD_VISION_API_KEY);

        Vision.Builder builder = new Vision.Builder(httpTransport, jsonFactory, null);
        builder.setVisionRequestInitializer(requestInitializer);

        Vision vision = builder.build();

        BatchAnnotateImagesRequest batchAnnotateImagesRequest =
                new BatchAnnotateImagesRequest();
        batchAnnotateImagesRequest.setRequests(new ArrayList<AnnotateImageRequest>() {
            {
                for (Bitmap bitmap : bitmaps) {
                    AnnotateImageRequest annotateImageRequest = new AnnotateImageRequest();

                    // Add the image
                    Image base64EncodedImage = new Image();
                    // Convert the bitmap to a JPEG
                    // Just in case it's a format that Android understands but Cloud Vision
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, byteArrayOutputStream);
                    byte[] imageBytes = byteArrayOutputStream.toByteArray();

                    // Base64 encode the JPEG
                    base64EncodedImage.encodeContent(imageBytes);
                    annotateImageRequest.setImage(base64EncodedImage);

                    // add the features we want
                    annotateImageRequest.setFeatures(new ArrayList<Feature>() {
                        {
                            for (FeatureType featureType : featureTypeList) {
                                add(featureType.newFeature());
                            }
                        }
                    });
                    // Add the list of one thing to the request
                    add(annotateImageRequest);
                }
            }
        });

        Vision.Images.Annotate annotateRequest =
                vision.images().annotate(batchAnnotateImagesRequest);
        // Due to a bug: requests to Vision API containing large images fail when GZipped.
        annotateRequest.setDisableGZipContent(true);

        return annotateRequest;
    }

    private Bitmap scaleBitmapDown(Bitmap bitmap, int maxDimension) {

        int originalWidth = bitmap.getWidth();
        int originalHeight = bitmap.getHeight();
        int resizedWidth = maxDimension;
        int resizedHeight = maxDimension;

        if (originalHeight > originalWidth) {
            resizedHeight = maxDimension;
            resizedWidth = (int) (resizedHeight * (float) originalWidth / (float) originalHeight);
        } else if (originalWidth > originalHeight) {
            resizedWidth = maxDimension;
            resizedHeight = (int) (resizedWidth * (float) originalHeight / (float) originalWidth);
        } else if (originalHeight == originalWidth) {
            resizedHeight = maxDimension;
            resizedWidth = maxDimension;
        }
        return Bitmap.createScaledBitmap(bitmap, resizedWidth, resizedHeight, false);
    }
}
