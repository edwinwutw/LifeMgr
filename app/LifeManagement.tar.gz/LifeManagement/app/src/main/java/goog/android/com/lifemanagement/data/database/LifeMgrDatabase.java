package goog.android.com.lifemanagement.data.database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;
import android.content.Context;
import android.util.Log;

/**
 * Created by edwinwu on 2018/3/27.
 */

/**
 * LifeMgrDatabase database for the application including a table for Event, Picture and
 * their associate EventPicture for many-to-many relations
 */

// List of the entry classes and associated TypeConverters
@Database(entities = {Event.class, PictureRepo.class, EventPictureJoin.class}, version = 1)
@TypeConverters(DateConverter.class)
public abstract class LifeMgrDatabase extends RoomDatabase {

    private static final String LOG_TAG = LifeMgrDatabase.class.getSimpleName();
    private static final String DATABASE_NAME = "LifeMgrDB";

    // For Singleton instantiation
    private static final Object LOCK = new Object();
    private static LifeMgrDatabase sInstance;

    public static LifeMgrDatabase getInstance(Context context) {
        //Log.d(LOG_TAG, "Getting the database");
        if (sInstance == null) {
            synchronized (LOCK) {
                sInstance = Room.databaseBuilder(context.getApplicationContext(),
                        LifeMgrDatabase.class, LifeMgrDatabase.DATABASE_NAME).build();
                Log.d(LOG_TAG, "Made new database");
            }
        }
        return sInstance;
    }

    // The associated DAOs for the database
    public abstract EventDao getEventDao();
    public abstract PictureRepoDao getPictureRepoDao();
    public abstract EventPictureJoinDao getEventPictureJoinDao();
}
