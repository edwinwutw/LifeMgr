package goog.android.com.lifemanagement.data.database;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;
import android.arch.persistence.room.Room;

import java.util.Date;

/**
 * Created by edwinwu on 2018/3/27.
 */

/**
 * an associate table to represent many-to-many relations for event <-> piture
 */
@Entity(tableName = "event_picture",
        primaryKeys = {"eventId", "pictureId"},
        foreignKeys = {
            @ForeignKey(entity = Event.class,
                        parentColumns = "id",
                        childColumns = "eventId"),
            @ForeignKey(entity = PictureRepo.class,
                        parentColumns = "id",
                        childColumns = "pictureId")
        })
public class EventPictureJoin {

    public final long eventId;
    public final long pictureId;

    public EventPictureJoin(final long eventId, final long pictureId) {
        this.eventId = eventId;
        this.pictureId = pictureId;
    }
}

