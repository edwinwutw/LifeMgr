package goog.android.com.lifemanagement.data.Classification;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import goog.android.com.lifemanagement.AppExecutors;
import goog.android.com.lifemanagement.data.collection.PictureUtils;
import goog.android.com.lifemanagement.data.database.Event;
import goog.android.com.lifemanagement.data.database.PictureRepo;
import goog.android.com.lifemanagement.data.database.PictureRepoList;
import goog.android.com.lifemanagement.service.ClusterIntentService;

/**
 * Provides an API for cluster images by way of either K-means, DBScan or Hierarchical Clustering
 */
public class ClusteringBox {
    private static final String TAG = ClusteringBox.class.getSimpleName();

    // For Singleton instantiation
    private static final Object LOCK = new Object();
    private static ClusteringBox sInstance;

    private final Context mContext;

    private ArrayList<Event> mEvents;

    // LiveData storing the latest event data
    private final MutableLiveData<Event[]> mClassifiedEvents;

    private final AppExecutors mExecutors;

    private ClusteringBox(Context context, AppExecutors executors) {
        mContext = context;
        mExecutors = executors;

        mClassifiedEvents = new MutableLiveData<>();
    }

    /**
     * Get the singleton for this class
     */
    public static ClusteringBox getInstance(Context context, AppExecutors executors) {
        //Log.d(TAG, "Getting the ClassificationBox");
        if (sInstance == null) {
            synchronized (LOCK) {
                sInstance = new ClusteringBox(context, executors);
                Log.d(TAG, "Made new ClassificationBox");
            }
        }
        return sInstance;
    }

    public LiveData<Event[]> getEvents() {
        return mClassifiedEvents;
    }

    public void startClassify() {
        Intent intentToCluster = new Intent(mContext, ClusterIntentService.class);
        intentToCluster.putExtra(ClusterIntentService.PARAM_IN_SERVICE, ClusterIntentService.CLUSTERING_PARAM);
        mContext.startService(intentToCluster);
        Log.d(TAG, "Service created:" + ClusterIntentService.CLUSTERING_PARAM);
    }

    public void updateClassify(List<PictureRepo> pictureRepos) {
        Intent intentToCluster = new Intent(mContext, ClusterIntentService.class);
        intentToCluster.putExtra(ClusterIntentService.PARAM_IN_SERVICE, ClusterIntentService.UPDATE_CLUSTERING_PARAM);
        PictureRepoList pictureRepoList = new PictureRepoList(pictureRepos);
        intentToCluster.putExtra(ClusterIntentService.PICTURELIST_PARAM, pictureRepoList);
        mContext.startService(intentToCluster);
        Log.d(TAG, "Service created:" + ClusterIntentService.UPDATE_CLUSTERING_PARAM);
    }

    /**
     * Gets the newest event; this function call must be called in a thread or intentservice
     */
    public void classify(List<PictureRepo> pictures) {
        Log.d(TAG, "Classify started>>");

        try {
            List<PictureRepo> pictureRepos = pictures;
            if (pictureRepos == null) { // if null, then we need to collect the images from mediastores
                pictureRepos = PictureUtils.getAllImageInfo(mContext);
            }

            ByDate(pictureRepos);
            Event[] events = makeEvent(mEvents);

            mClassifiedEvents.postValue(events);

            Log.d(TAG, "Classify end");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void ByDate(List<PictureRepo> pictureRepos) {
        mEvents = new ArrayList<>();
        for (int i = 0; i < pictureRepos.size(); i++) {
            if (mEvents.isEmpty() == true) {
                Event event = new Event(pictureRepos.get(i).getExifDate().toString(),
                        pictureRepos.get(i).getExifDate().toString(),
                        pictureRepos.get(i).getExifDate(),
                        pictureRepos.get(i).getExifLatitude(),
                        pictureRepos.get(i).getExifLongitude(),
                        pictureRepos.get(i).getImagePath(),
                        "",
                        pictureRepos.get(i).getReceiptAmount(),
                        1);
                event.addPictureRepo(pictureRepos.get(i));
                mEvents.add(event);
            } else {
                Event lastEvent = mEvents.get(mEvents.size() - 1);

                if (pictureRepos.get(i).getExifDate().isEqual(lastEvent.getDate())) {
                    lastEvent.addPictureRepo(pictureRepos.get(i));
                    mEvents.set(mEvents.size() - 1 , lastEvent);
                } else {
                    Event event = new Event(pictureRepos.get(i).getExifDate().toString(),
                            pictureRepos.get(i).getExifDate().toString(),
                            pictureRepos.get(i).getExifDate(),
                            pictureRepos.get(i).getExifLatitude(),
                            pictureRepos.get(i).getExifLongitude(),
                            pictureRepos.get(i).getImagePath(),
                            "",
                            pictureRepos.get(i).getReceiptAmount(),
                            1);
                    event.addPictureRepo(pictureRepos.get(i));
                    mEvents.add(event);
                }
            }
        }
    }

    private Event[] makeEvent(List<Event> events) {
        for (int i = 0; i < events.size(); i++) {
            Event event = events.get(i);
            if (event.getPictureRepos().size() > 1) {
                double totalAmount = 0;
                for (int j = 0; j < event.getPictureRepos().size(); j++) {
                    totalAmount = totalAmount + event.getPictureRepos().get(j).getReceiptAmount();
                }
                event.setTotalAmount(totalAmount);
                event.setPictureNumber(event.getPictureRepos().size());
                events.set(i, event);
            }
        }
        return events.toArray(new Event[0]);
    }

}