package goog.android.com.lifemanagement.data.database;

import android.arch.persistence.room.TypeConverter;

import java.time.LocalDate;

/**
 * Created by edwinwu on 2018/3/27.
 */

/**
 * {@link TypeConverter} for long to {@link LocalDate}
 * <p>
 * This stores the date as a long in the database, but returns it as a {@link LocalDate}
 */
class DateConverter {
    @TypeConverter
    public static LocalDate toDate(Long dateLong) {
        return dateLong == null ? null : LocalDate.ofEpochDay(dateLong);
    }

    @TypeConverter
    public static Long fromDate(LocalDate date) {
        return date == null ? null : date.toEpochDay();
    }
}
