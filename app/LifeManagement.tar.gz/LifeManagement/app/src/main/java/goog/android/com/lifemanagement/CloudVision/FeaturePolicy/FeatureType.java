package goog.android.com.lifemanagement.CloudVision.FeaturePolicy;

import android.content.ContentValues;

import com.google.api.services.vision.v1.model.AnnotateImageResponse;
import com.google.api.services.vision.v1.model.Feature;

/**
 * Created by edwinwu on 2018/4/17
 */

public interface FeatureType {
    // derived class needs override TYPE
    String TYPE = "UNDEFINED";

    Feature       newFeature();
    ContentValues detectResult(AnnotateImageResponse annotateImageResponse);
}
