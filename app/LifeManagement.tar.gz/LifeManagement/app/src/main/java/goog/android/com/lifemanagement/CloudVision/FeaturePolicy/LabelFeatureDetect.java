/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package goog.android.com.lifemanagement.CloudVision.FeaturePolicy;

import android.content.ContentValues;

import com.google.api.services.vision.v1.model.AnnotateImageResponse;
import com.google.api.services.vision.v1.model.EntityAnnotation;
import com.google.api.services.vision.v1.model.Feature;

import java.util.List;

/**
 * label detection, the TYPE is "LABEL_DETECTION"
 */

public class LabelFeatureDetect implements FeatureType {
    String TYPE = "LABEL_DETECTION";

    // contentvalues key
    public final static String CONTENTVALUE_KEY = "label";

    private static final int MAX_RESULTS = 25;

    @Override
    public Feature newFeature() {
        Feature feature = new Feature();
        feature.setType(TYPE);
        feature.setMaxResults(MAX_RESULTS);

        return feature;
    }

    @Override
    public ContentValues detectResult(final AnnotateImageResponse air) {
        if (air == null) return null;

        ContentValues cv = new ContentValues();
        List<EntityAnnotation> entitylabels = air.getLabelAnnotations();
        StringBuilder labelBuilder = new StringBuilder();
        if (entitylabels != null) {
            for (EntityAnnotation label : entitylabels) {
                labelBuilder.append(label.getDescription() + ";");
            }
            cv.put(CONTENTVALUE_KEY, labelBuilder.toString());
        }

        return cv;
    }

}
