package goog.android.com.lifemanagement.CloudVision.FeaturePolicy;


import android.content.ContentValues;

import com.google.api.services.vision.v1.model.AnnotateImageResponse;
import com.google.api.services.vision.v1.model.EntityAnnotation;
import com.google.api.services.vision.v1.model.Feature;

import java.util.List;

/**
 * Created by edwinwu on 2018/4/17
 */

public class LabelFeatureDetect implements FeatureType {
    String TYPE = "LABEL_DETECTION";

    // contentvalues key
    public final static String CONTENTVALUE_KEY = "label";

    private static final int MAX_RESULTS = 25;

    @Override
    public Feature newFeature() {
        Feature feature = new Feature();
        feature.setType(TYPE);
        feature.setMaxResults(MAX_RESULTS);

        return feature;
    }

    @Override
    public ContentValues detectResult(AnnotateImageResponse air) {
        if (air == null) return null;

        ContentValues cv = new ContentValues();
        List<EntityAnnotation> entitylabels = air.getLabelAnnotations();
        StringBuilder labelBuilder = new StringBuilder();
        if (entitylabels != null) {
            for (EntityAnnotation label : entitylabels) {
                labelBuilder.append(label.getDescription() + ";");
            }
            cv.put(CONTENTVALUE_KEY, labelBuilder.toString());
        }

        return cv;
    }

}
