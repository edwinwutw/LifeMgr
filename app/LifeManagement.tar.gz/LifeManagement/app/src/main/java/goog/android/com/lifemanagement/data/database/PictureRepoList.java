package goog.android.com.lifemanagement.data.database;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PictureRepoList implements Serializable {
    private List<PictureRepo> mPictureRepos;

    public PictureRepoList(List<PictureRepo> pictureRepos) {
        this.mPictureRepos = pictureRepos;
    }

    public List<PictureRepo> getPictureRepos() {
        return mPictureRepos;
    }
}
