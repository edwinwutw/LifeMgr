/**
 * Copyright 2017 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package goog.android.com.lifemanagement.ui;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonElement;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import ai.api.AIServiceException;
import ai.api.RequestExtras;
import ai.api.android.AIConfiguration;
import ai.api.android.AIDataService;
import ai.api.android.GsonFactory;
import ai.api.model.AIContext;
import ai.api.model.AIError;
import ai.api.model.AIEvent;
import ai.api.model.AIRequest;
import ai.api.model.AIResponse;
import ai.api.model.Metadata;
import ai.api.model.Result;
import ai.api.model.Status;
import goog.android.com.lifemanagement.Dialogflow.Config;
import goog.android.com.lifemanagement.R;
import goog.android.com.lifemanagement.data.database.PictureRepo;
import goog.android.com.lifemanagement.utils.InjectorUtils;

import static ai.api.util.ParametersConverter.PROTOCOL_DATE_FORMAT;

/**
 * Created by alexey on 07/12/16.
 */
public class AISearchActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String TAG = "AISearchActivity";


    private Gson gson = GsonFactory.getGson();

    private TextView resultTextView;
    private EditText queryEditText;
    private AIDataService aiDataService;


    private final class SearchEntitiy {

        boolean mbSearchTotalMoney;
        LocalDate mStartLocalDate;
        LocalDate mEndLocalDate;

    }

    private SearchEntitiy mSearchEntity = new SearchEntitiy();;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.search_activity);

        resultTextView = (TextView) findViewById(R.id.resultTextView);
        queryEditText = (EditText) findViewById(R.id.textQuery);

        findViewById(R.id.buttonSend).setOnClickListener(this);
        findViewById(R.id.buttonClear).setOnClickListener(this);

        // initService();

    }

    private void initService(AIConfiguration.SupportedLanguages lang) {

        //final AIConfiguration.SupportedLanguages lang = AIConfiguration.SupportedLanguages.ChineseTaiwan;//AIConfiguration.SupportedLanguages.fromLanguageTag("en");
        final AIConfiguration config = new AIConfiguration(Config.ACCESS_TOKEN,
                lang,
                AIConfiguration.RecognitionEngine.System);


        aiDataService = new AIDataService(this, config);

    }


    private void clearEditText() {
        queryEditText.setText("");
        resultTextView.setText("");
        mSearchEntity.mbSearchTotalMoney = false;
    }


    
    private boolean checkIfEnglishText(String str) {

        boolean isEnglish = true;
        for ( char c : str.toCharArray() ) {
            if ( Character.UnicodeBlock.of(c) != Character.UnicodeBlock.BASIC_LATIN ) {
                isEnglish = false;
                break;
            }
        }

        return isEnglish;
    }

    /*
    * AIRequest should have query OR event
    */
    private void sendRequest() {

        final String queryString =  String.valueOf(queryEditText.getText());

        if (TextUtils.isEmpty(queryString) ) {
            onError(new AIError(getString(R.string.non_empty_query)));
            return;
        }

        if ( checkIfEnglishText(queryString) ) {
            initService(AIConfiguration.SupportedLanguages.English);
        } else {
            initService(AIConfiguration.SupportedLanguages.ChineseTaiwan);
        }



        final AsyncTask<String, Void, AIResponse> task = new AsyncTask<String, Void, AIResponse>() {

            private AIError aiError;

            @Override
            protected AIResponse doInBackground(final String... params) {
                final AIRequest request = new AIRequest();
                String query = params[0];

                if (!TextUtils.isEmpty(query))
                    request.setQuery(query);


                try {
                    return aiDataService.request(request);
                } catch (final AIServiceException e) {
                    aiError = new AIError(e);
                    return null;
                }
            }

            @Override
            protected void onPostExecute(final AIResponse response) {
                if (response != null) {
                    onResult(response);
                } else {
                    onError(aiError);
                }
            }
        };

        task.execute(queryString);
    }

    private void onResult(final AIResponse response) {
        Log.d(TAG, "onResult");
        //

        //background to parsing total money
        new AsyncTask<Void, Void, Integer>() {
            @Override
            protected Integer doInBackground(Void... params) {

                int totalMoney=0;
                if( parseUserEntity(response)) {

                    totalMoney = getTotalAmountForUserSearch();
                }
                return totalMoney;
            }

            @Override
            protected void onPostExecute(Integer totalMoney) {

                if(totalMoney >0)
                    resultTextView.setText(Integer.toString(totalMoney));
                else
                    resultTextView.setText("There is no any expense record found");

            }
        }.execute();




    }


    private boolean parseUserEntity(AIResponse response) {

        Log.i(TAG, "Received success response");

        // this is example how to get different parts of result object
        final Status status = response.getStatus();
        Log.i(TAG, "Status code: " + status.getCode());
        Log.i(TAG, "Status type: " + status.getErrorType());

        final Result result = response.getResult();
        Log.i(TAG, "Resolved query: " + result.getResolvedQuery());


        // didn't get financial data
        if(result.getStringParameter("finance_amount").length() <=0) {
            mSearchEntity.mbSearchTotalMoney = false;
            return false;
        }

        // find user want to query total amount
            mSearchEntity.mbSearchTotalMoney = true;

            Date startDate;
            startDate =  result.getDateParameter("date");

            Log.i(TAG, "date: " + startDate);

            if (startDate != null && startDate.toInstant()!= null) {
                // for one day case

                mSearchEntity.mStartLocalDate = startDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                mSearchEntity.mEndLocalDate =  mSearchEntity.mStartLocalDate;
            } else {

                // get date period
                String datePeriod = result.getStringParameter("date-period"); // ex: 2018-04-23/2018-04-29
                Log.i(TAG, "datePeriod: " + datePeriod);

                if( !datePeriod.isEmpty()) {

                    String[] dateArr = datePeriod.split("/");

                    try {
                        Date endDate;
                        startDate = new SimpleDateFormat(PROTOCOL_DATE_FORMAT, Locale.US).parse(dateArr[0]);
                        endDate = new SimpleDateFormat(PROTOCOL_DATE_FORMAT, Locale.US).parse(dateArr[1]);

                        if ( startDate != null && endDate != null ) {
                            mSearchEntity.mStartLocalDate = startDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                            mSearchEntity.mEndLocalDate = endDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }


                }

            }


        final HashMap<String, JsonElement> params = result.getParameters();
        if (params != null && !params.isEmpty()) {
            Log.i(TAG, "Parameters: ");
            for (final Map.Entry<String, JsonElement> entry : params.entrySet()) {
                Log.i(TAG, String.format("%s: %s", entry.getKey(), entry.getValue().toString()));
            }
        }

       return true;
    }


    private int getTotalAmountForUserSearch(){
        int total = 0;
        if (mSearchEntity.mbSearchTotalMoney ) {

            List<PictureRepo> picList =  InjectorUtils.provideRepository(this.getApplicationContext()).getAllPictures();


            for (int i=0; i<picList.size(); i++) {
                LocalDate date = picList.get(i).getReceiptDate();
                if(date == null ) continue;

                if (date.isBefore(mSearchEntity.mStartLocalDate) || date.isAfter(mSearchEntity.mEndLocalDate)) continue;

                total += picList.get(i).getReceiptAmount();

                Log.i(TAG, "find matched receipt date > "+ picList.get(i).getReceiptDate());
                Log.i(TAG, "find matched receipt money > "+ picList.get(i).getReceiptAmount());
                Log.i(TAG, "total money "+ total);
            }
        }

       return total;
    }

    private void onError(final AIError error) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                resultTextView.setText(error.toString());
            }
        });
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buttonClear:
                clearEditText();
                break;
            case R.id.buttonSend:
                sendRequest();
                break;
        }
    }
}
