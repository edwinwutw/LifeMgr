/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package goog.android.com.lifemanagement.CloudVision.FeaturePolicy;

import android.content.ContentValues;
import android.support.annotation.VisibleForTesting;

import com.google.api.services.vision.v1.model.AnnotateImageResponse;
import com.google.api.services.vision.v1.model.EntityAnnotation;
import com.google.api.services.vision.v1.model.Feature;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * OCR detection, the TYPE is "TEXT_DETECTION". Use TEXT_DETECTION to detect receipt
 * date, total amount...,etc.
 */

public class ReceiptFeatureDetect implements FeatureType {
    private static final String TAG = ReceiptFeatureDetect.class.getSimpleName();

    String TYPE = "TEXT_DETECTION";

    // contentvalues key
    public final static String CONTENTVALUE_RECEIPT_KEY   = "isreceipt";
    public final static String CONTENTVALUE_AMOUNT_KEY    = "receiptamount";
    public final static String CONTENTVALUE_DATE_KEY      = "receiptdate";
    public final static String CONTENTVALUE_RECEIPTNO_KEY = "receiptno";

    @Override
    public Feature newFeature() {
        Feature feature = new Feature();
        feature.setType(TYPE);

        return feature;
    }

    @Override
    public ContentValues detectResult(final AnnotateImageResponse air) {
        if (air == null) return null;

        ContentValues cv = new ContentValues();
        final List<EntityAnnotation> textlabels = air.getTextAnnotations();
        if (textlabels != null) {
            boolean dateFound = false; // the receipt date will be set at the first found
            boolean totalAmountFound = false;
            boolean numberFound = false;
            int textNums = textlabels.size();
            // iterate each text of detection results
            for (int i = 0; i < textNums; i++) {
                final EntityAnnotation ea = textlabels.get(i);
                final String parsedString = ea.getDescription();

                if (i != 0) {
                    final Optional<LocalDate> localDateop = parseDate(parsedString);
                    // see if date TEXT is found; we always take the first appearance as our
                    // detected date
                    if (localDateop.isPresent() && !dateFound) {
                        cv.put(CONTENTVALUE_DATE_KEY, String.valueOf(localDateop.get()));
                        dateFound = true;

                        continue;
                    }
                    // see if total amount is found; we always take the back/forth 1-3 index
                    // and see if one of them is "總計" or "Total"
                    final Optional<Float> moneyop = parseMoney(parsedString);
                    if (moneyop.isPresent() && !totalAmountFound) {
                        if (textHasMatchedStringNearIndex("總計", textlabels, i) ||
                                textHasMatchedStringNearIndex("Total", textlabels, i)) {
                            cv.put(CONTENTVALUE_AMOUNT_KEY, moneyop.get());
                            cv.put(CONTENTVALUE_RECEIPT_KEY, true);
                            totalAmountFound = true;
                        }

                        continue;
                    }
                    // see if receipt number is found; the pattern is "[A-Z]{2}-[0-9]{8}" whose
                    // total character number are 10
                    final Optional<String> receiptnoop = parseReceiptNo(parsedString);
                    if (receiptnoop.isPresent() && !numberFound) {
                        cv.put(CONTENTVALUE_RECEIPTNO_KEY, receiptnoop.get());
                        numberFound = true;

                        continue;
                    }
                }

                if (dateFound && totalAmountFound && numberFound) // all found then exit;
                    break;
            }
        }

        return cv;
    }

    // pattern for matching date formats
    private static final DateTimeFormatter[] possibleDateFormats = {
            //YMD
            DateTimeFormatter.ofPattern("uuuu/M/d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu/MMM/d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu/MMMM/d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu/M/d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu/MMM/d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu/MMMM/d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu-M-d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu-MMM-d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu-MMMMM-d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu-M-d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu-MMM-d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu-MMMM-d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu.M.d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu.MMM.d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu.MMMM.d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu.M.d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu.MMM.d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu.MMMM.d").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            //DMY
            DateTimeFormatter.ofPattern("d/M/uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d/MMM/uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d/MMMM/uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d/M/uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d/MMM/uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d/MMMM/uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-M-uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-MMM-uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-MMMM-uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-M-uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-MMM-uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-MMMM-uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.M.uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.MMM.uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.MMMM.uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.M.uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.MMM.uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.MMMM.uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            //MDY
            DateTimeFormatter.ofPattern("M/d/uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d/uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d/uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M/d/uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d/uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d/uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M/d, uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d, uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d, uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M/d,uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d,uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d,uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M/d, uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d, uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d, uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M/d,uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d,uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d,uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M d, uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM d, uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM d, uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M d,uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM d,uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM d,uuuu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M d, uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM d, uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM d uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M d,uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM d,uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM d,uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMd''uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM d''uu").withLocale(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT)

    };

    @VisibleForTesting
    Optional<LocalDate> parseDate(final String possibleDate) {
        for (DateTimeFormatter format : possibleDateFormats) {
            try {
                LocalDate result = LocalDate.parse(possibleDate, format);
                return Optional.of(result);
            } catch (DateTimeParseException e) {
                // ignore, try next format
            }
        }
        return Optional.empty();
    }

    @VisibleForTesting
    Optional<Float> parseMoney(final String possibleMoney) {
        final String regex = "(([1-9]\\d{0,2}(,\\d{3})*)|(([1-9]\\d*)?\\d))(\\.\\d\\d)?";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(possibleMoney);
        if (m.matches()) {
            float money = 0;
            try {
                money = Float.parseFloat(possibleMoney);
                return Optional.of(money);
            } catch (NumberFormatException ne) {
                return Optional.empty();
            }
        }
        return Optional.empty();
    }

    @VisibleForTesting
    Optional<String> parseReceiptNo(final String possibleReceiptNo) {
        final String regex = "[A-Z]{2}-?[0-9]{8}";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(possibleReceiptNo);
        if (m.matches()) {
            return Optional.of(possibleReceiptNo);
        }
        return Optional.empty();
    }

    private boolean textHasMatchedStringNearIndex(final String matchedString,
                                                  final List<EntityAnnotation> textlabels,
                                                  final int index) {
        boolean match = false;
        int ix, iy, iz = 0;
        if (index >= 3) {
            match = textlabels.get(index-3).getDescription().contentEquals(matchedString) ||
                    textlabels.get(index-2).getDescription().contentEquals(matchedString) ||
                    textlabels.get(index-1).getDescription().contentEquals(matchedString);
        } else if (index == 2) {
            match = textlabels.get(index-2).getDescription().contentEquals(matchedString) ||
                    textlabels.get(index-1).getDescription().contentEquals(matchedString);
        } else if (index == 1) {
            match = textlabels.get(index-1).getDescription().contentEquals(matchedString);
        } else
            match = false;

        return match;
    }
}