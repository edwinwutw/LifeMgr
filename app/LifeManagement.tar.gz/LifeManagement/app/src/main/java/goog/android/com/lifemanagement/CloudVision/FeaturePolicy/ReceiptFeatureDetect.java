package goog.android.com.lifemanagement.CloudVision.FeaturePolicy;

import android.content.ContentValues;

import com.google.api.services.vision.v1.model.AnnotateImageResponse;
import com.google.api.services.vision.v1.model.EntityAnnotation;
import com.google.api.services.vision.v1.model.Feature;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReceiptFeatureDetect implements FeatureType {
    String TYPE = "TEXT_DETECTION";

    // contentvalues key
    public final static String CONTENTVALUE_RECEIPT_KEY   = "isreceipt";
    public final static String CONTENTVALUE_AMOUNT_KEY    = "receiptamount";
    public final static String CONTENTVALUE_DATE_KEY      = "receiptdate";
    public final static String CONTENTVALUE_RECEIPTNO_KEY = "receiptno";

    @Override
    public Feature newFeature() {
        Feature feature = new Feature();
        feature.setType(TYPE);

        return feature;
    }

    @Override
    public ContentValues detectResult(AnnotateImageResponse air) {
        if (air == null) return null;

        ContentValues cv = new ContentValues();
        List<EntityAnnotation> textlabels = air.getTextAnnotations();
        if (textlabels != null) {
            boolean dateFound = false; // the receipt date will be set at the first found
            boolean totalAmountFound = false;
            boolean numberFound = false;
            int textNums = textlabels.size();
            for (int i = 0; i < textNums; i++) {
                EntityAnnotation ea = textlabels.get(i);
                try {
                    String parsedString = ea.getDescription();
                    if (i != 0) {
                        LocalDate date;
                        Optional<LocalDate> localDateop = parseDate(parsedString);
                        if (localDateop.isPresent() && false == dateFound) {
                            cv.put(CONTENTVALUE_DATE_KEY, String.valueOf(localDateop.get()));
                            dateFound = true;

                            continue;
                        }
                        Optional<Float> moneyop = parseMoney(parsedString);
                        if (moneyop.isPresent() && false == totalAmountFound) {
                            if (textHasMatchedStringNearIndex("總計", textlabels, i) ||
                                    textHasMatchedStringNearIndex("Total", textlabels, i)) {
                                cv.put(CONTENTVALUE_AMOUNT_KEY, moneyop.get());
                                cv.put(CONTENTVALUE_RECEIPT_KEY, true);
                                totalAmountFound = true;
                            }

                            continue;
                        }
                        Optional<String> receiptnoop = parseReceiptNo(parsedString);
                        if (receiptnoop.isPresent() && false == numberFound) {
                            cv.put(CONTENTVALUE_RECEIPTNO_KEY, receiptnoop.get());
                            numberFound = true;

                            continue;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    continue;
                }

                if (dateFound && totalAmountFound && numberFound) // all found then break;
                    break;
            }
        }

        return cv;
    }

    // pattern for matching date formats
    private static final DateTimeFormatter[] possibleDateFormats = {
            //YMD
            DateTimeFormatter.ofPattern("uuuu/M/d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu/MMM/d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu/MMMM/d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu/M/d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu/MMM/d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu/MMMM/d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu-M-d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu-MMM-d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu-MMMMM-d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu-M-d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu-MMM-d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu-MMMM-d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu.M.d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu.MMM.d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uuuu.MMMM.d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu.M.d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu.MMM.d").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("uu.MMMM.d").withResolverStyle(ResolverStyle.STRICT),
            //DMY
            DateTimeFormatter.ofPattern("d/M/uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d/MMM/uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d/MMMM/uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d/M/uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d/MMM/uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d/MMMM/uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-M-uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-MMM-uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-MMMM-uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-M-uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-MMM-uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d-MMMM-uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.M.uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.MMM.uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.MMMM.uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.M.uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.MMM.uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("d.MMMM.uu").withResolverStyle(ResolverStyle.STRICT),
            //MDY
            DateTimeFormatter.ofPattern("M/d/uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d/uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d/uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M/d/uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d/uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d/uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M/d, uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d, uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d, uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M/d,uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d,uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d,uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M/d, uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d, uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d, uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M/d,uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM/d,uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM/d,uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M d, uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM d, uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM d, uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M d,uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM d,uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM d,uuuu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M d, uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM d, uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM d uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M d,uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM d,uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMM d,uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMMd''uu").withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("MMM d''uu").withResolverStyle(ResolverStyle.STRICT)

    };

    private Optional<LocalDate> parseDate(String possibleDate) {
        for (DateTimeFormatter format : possibleDateFormats) {
            try {
                LocalDate result = LocalDate.parse(possibleDate, format);
                return Optional.of(result);
            } catch (DateTimeParseException e) {
                // ignore, try next format
                //e.printStackTrace();
            }
        }
        return Optional.empty();
    }

    private Optional<Float> parseMoney(String possibleMoney) {
        String regex = "(([1-9]\\d{0,2}(,\\d{3})*)|(([1-9]\\d*)?\\d))(\\.\\d\\d)?";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(possibleMoney);
        if (m.matches()) {
            float money = 0;
            try {
                money = Float.parseFloat(possibleMoney);
                return Optional.of(money);
            } catch (NumberFormatException ne) {
                return Optional.empty();
            }
        }
        return Optional.empty();
    }

    private Optional<String> parseReceiptNo(String possibleReceiptNo) {
        String regex = "[A-Z]{2}-[0-9]{8}";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(possibleReceiptNo);
        if (m.matches()) {
            return Optional.of(possibleReceiptNo);
        }
        return Optional.empty();
    }

    private boolean textHasMatchedStringNearIndex(String matchedString,
                                                  List<EntityAnnotation> textlabels, int index) {
        boolean match = false;
        int ix, iy, iz = 0;
        if (index >= 3) {
            match = textlabels.get(index-3).getDescription().contentEquals(matchedString) ||
                    textlabels.get(index-2).getDescription().contentEquals(matchedString) ||
                    textlabels.get(index-1).getDescription().contentEquals(matchedString);
        } else if (index == 2) {
            match = textlabels.get(index-2).getDescription().contentEquals(matchedString) ||
                    textlabels.get(index-1).getDescription().contentEquals(matchedString);
        } else if (index == 1) {
            match = textlabels.get(index-1).getDescription().contentEquals(matchedString);
        } else
            match = false;

        return match;
    }
}