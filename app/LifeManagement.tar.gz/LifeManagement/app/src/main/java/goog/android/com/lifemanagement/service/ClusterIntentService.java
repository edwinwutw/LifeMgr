/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package goog.android.com.lifemanagement.service;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import java.util.HashMap;

import goog.android.com.lifemanagement.CloudVision.CloudVisionApi;
import goog.android.com.lifemanagement.data.Classification.ClusteringBox;
import goog.android.com.lifemanagement.data.database.PictureRepoList;
import goog.android.com.lifemanagement.utils.InjectorUtils;

/**
 * Android IntentService to handle clustering and ClousVision long term job
 */

public class ClusterIntentService extends IntentService {
    private static final String TAG = ClusterIntentService.class.getSimpleName();

    public static final String PARAM_IN_SERVICE  = "intent_service";
    public static final String CLUSTERING_PARAM  = "clustering";
    public static final String UPDATE_CLUSTERING_PARAM = "update_clustering";
    public static final String CLOUDVISION_PARAM = "cloudvision";
    public static final String PICTURELIST_PARAM = "picturelist";

    public ClusterIntentService() {
        super("ClusterIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Log.d(TAG, "Intent service started");

        String param_category = intent.getStringExtra(PARAM_IN_SERVICE);

        if (param_category.equalsIgnoreCase(CLUSTERING_PARAM)) {
            ClusteringBox clusteringBox =
                    InjectorUtils.provideClusteringBox(this.getApplicationContext());
            clusteringBox.classify(null);
        } else if (param_category.equalsIgnoreCase(UPDATE_CLUSTERING_PARAM)) {
            PictureRepoList pictureRepoList = (PictureRepoList) intent.getSerializableExtra(PICTURELIST_PARAM);

            if (pictureRepoList != null) {
                ClusteringBox clusteringBox =
                        InjectorUtils.provideClusteringBox(this.getApplicationContext());
                clusteringBox.classify(pictureRepoList.getPictureRepos());
            }

        } else if (param_category.equalsIgnoreCase(CLOUDVISION_PARAM)) {
            Bundle bundle = intent.getExtras();
            HashMap<Integer, String> hashMap = null;
            if (bundle != null) {
                hashMap = (HashMap<Integer, String>)bundle.getSerializable("HashMap");
            }

            if (hashMap == null) return;

            CloudVisionApi cloudVisionApi =
                    InjectorUtils.provideCloudVisionApi(this.getApplicationContext());
            cloudVisionApi.analyzeImagesByCloudVision(this.getApplicationContext(), hashMap);
        }
    }
}