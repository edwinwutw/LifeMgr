package goog.android.com.lifemanagement.service;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import java.util.HashMap;

import goog.android.com.lifemanagement.CloudVision.CloudVisionApi;
import goog.android.com.lifemanagement.data.Classification.ClusteringBox;
import goog.android.com.lifemanagement.data.database.PictureRepoList;
import goog.android.com.lifemanagement.utils.InjectorUtils;

/**
 * Created by edwinwu on 2018/4/02.
 */

public class ClusterIntentService extends IntentService {
    private static final String TAG = ClusterIntentService.class.getSimpleName();

    public static final String PARAM_IN_SERVICE  = "intent_service";
    public static final String CLUSTERING_PARAM  = "clustering";
    public static final String UPDATE_CLUSTERING_PARAM = "update_clustering";
    public static final String CLOUDVISION_PARAM = "cloudvision";
    public static final String PICTURELIST_PARAM = "picturelist";

    public ClusterIntentService() {
        super("ClusterIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Log.d(TAG, "Intent service started");

        String param_category = intent.getStringExtra(PARAM_IN_SERVICE);

        if (param_category.equalsIgnoreCase(CLUSTERING_PARAM)) {
            ClusteringBox clusteringBox =
                    InjectorUtils.provideClusteringBox(this.getApplicationContext());
            clusteringBox.classify(null);
        } else if (param_category.equalsIgnoreCase(UPDATE_CLUSTERING_PARAM)) {
            PictureRepoList pictureRepoList = (PictureRepoList) intent.getSerializableExtra(PICTURELIST_PARAM);

            if (pictureRepoList != null) {
                ClusteringBox clusteringBox =
                        InjectorUtils.provideClusteringBox(this.getApplicationContext());
                clusteringBox.classify(pictureRepoList.getPictureRepos());
            }

        } else if (param_category.equalsIgnoreCase(CLOUDVISION_PARAM)) {
            Bundle bundle = intent.getExtras();
            HashMap<Integer, String> hashMap = null;
            if (bundle != null) {
                hashMap = (HashMap<Integer, String>)bundle.getSerializable("HashMap");
            }

            if (hashMap == null) return;

            CloudVisionApi cloudVisionApi =
                    InjectorUtils.provideCloudVisionApi(this.getApplicationContext());
            cloudVisionApi.analyzeImagesByCloudVision(this.getApplicationContext(), hashMap);
        }
    }
}