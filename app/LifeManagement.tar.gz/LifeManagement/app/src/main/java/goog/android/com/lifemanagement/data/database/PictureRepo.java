package goog.android.com.lifemanagement.data.database;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Created by edwinwu on 2018/3/27.
 */

/**
 * Defines the schema of a table in Room for scanned of images.
 *
 */
@Entity(tableName = "picturerepo")
public class PictureRepo implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int       id;
    private String    imagePath;
    private LocalDate exifDate;
    private double    exifLatitude;
    private double    exifLongitude;
    private boolean   sentToCloudVision;
    private boolean   isReceipt;
    private String    labelDetected;
    private int       faceNo;
    private double    receiptAmount;
    private String    receiptNo;
    private LocalDate receiptDate;

    /**
     * This constructor is used by Classification_BlackBox...
     */
    @Ignore
    public PictureRepo(String imagePath, LocalDate exifDate, double exifLatitude, double exifLongitude,
                       boolean sentToCloudVision, boolean isReceipt, String labelDetected,
                       int faceNo, double receiptAmount, String receiptNo, LocalDate receiptDate) {
        this.imagePath = imagePath;
        this.exifDate = exifDate;
        this.exifLatitude = exifLatitude;
        this.exifLongitude = exifLongitude;

        this.sentToCloudVision = sentToCloudVision;

        this.isReceipt = isReceipt;
        this.labelDetected = labelDetected;
        this.faceNo = faceNo;
        this.receiptAmount = receiptAmount;
        this.receiptNo = receiptNo;
        this.receiptDate = receiptDate;
    }

    // Constructor used by Room to create PictureRepo
    public PictureRepo(int id, String imagePath, LocalDate exifDate, double exifLatitude, double exifLongitude,
                       boolean sentToCloudVision, boolean isReceipt, String labelDetected,
                       int faceNo, double receiptAmount, String receiptNo, LocalDate receiptDate) {
        this.id = id;
        this.imagePath = imagePath;
        this.exifDate = exifDate;
        this.exifLatitude = exifLatitude;
        this.exifLongitude = exifLongitude;

        this.sentToCloudVision = sentToCloudVision;

        this.isReceipt = isReceipt;
        this.labelDetected = labelDetected;
        this.faceNo = faceNo;
        this.receiptAmount = receiptAmount;
        this.receiptNo = receiptNo;
        this.receiptDate = receiptDate;
    }

    public int getId() {
        return id;
    }

    public String getImagePath() {
        return imagePath;
    }

    public LocalDate getExifDate() {
        return exifDate;
    }

    public double getExifLatitude() {
        return exifLatitude;
    }

    public double getExifLongitude() {
        return exifLongitude;
    }

    public boolean isSentToCloudVision() {
        return sentToCloudVision;
    }

    public void setSentToCloudVision(final boolean sentToCloudVision)
    {
        this.sentToCloudVision = sentToCloudVision;
    }

    public boolean isReceipt() {
        return isReceipt;
    }

    public void setIsReceipt(final boolean isReceipt)
    {
        this.isReceipt = isReceipt;
    }

    public String getLabelDetected() {
        return labelDetected;
    }

    public void setLabelDetected(final String labelDetected)
    {
        this.labelDetected = labelDetected;
    }

    public int getFaceNo() {
        return faceNo;
    }

    public void setFaceNo(final int faceNo)
    {
        this.faceNo = faceNo;
    }

    public double getReceiptAmount() {
        return receiptAmount;
    }

    public void setReceiptAmount(final double receiptAmount)
    {
        this.receiptAmount = receiptAmount;
    }

    public String getReceiptNo() {
        return receiptNo;
    }

    public void setReceiptNo(final String receiptNo)
    {
        this.receiptNo = receiptNo;
    }

    public LocalDate getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(final LocalDate receiptDate)
    {
        this.receiptDate = receiptDate;
    }
}
