package goog.android.com.lifemanagement.utils;

/**
 * Exception thrown by DBSCANClusterer.
 */

public class DBScan_ClusterException extends Exception {
    public DBScan_ClusterException(String string) {
        super(string);
    }
}