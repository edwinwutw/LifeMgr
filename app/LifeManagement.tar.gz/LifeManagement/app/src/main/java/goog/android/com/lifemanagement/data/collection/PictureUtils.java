package goog.android.com.lifemanagement.data.collection;

import android.content.Context;
import android.database.Cursor;
import android.media.ExifInterface;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import goog.android.com.lifemanagement.data.database.PictureRepo;

public class PictureUtils {
    private static final String TAG = "PictureUtils";


    private static ArrayList<String> getAllMediaStoreImgPath(Context context) {
        Uri uri;
        Cursor cursor;
        int column_index;

        ArrayList<String> listOfAllImages = new ArrayList<String>();
        String absolutePathOfImage = null;
        uri = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {MediaStore.MediaColumns.DATA,
                MediaStore.MediaColumns.DISPLAY_NAME};

        cursor = context.getContentResolver().query(uri, projection, null, null, null);
        column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        while (cursor.moveToNext()) {

            absolutePathOfImage = cursor.getString(column_index);
            listOfAllImages.add(absolutePathOfImage);
        }
        return listOfAllImages;
    }

    public static ArrayList<PictureRepo> getAllImageInfo(Context context) {

        final ArrayList<String> imagePathList = getAllMediaStoreImgPath(context);
        if (imagePathList.size() == 0) return null; // no need to go on


        ArrayList<PictureRepo> pictureRepos = new ArrayList<>();

        try {
            for (int i = 0; i < imagePathList.size(); i++) {
                String imagePath = imagePathList.get(i);

                ExifInterface exif = null;

                exif = new ExifInterface(imagePath);

                double exif_latitude = 0;
                double exif_longitude = 0;
                LocalDate date = LocalDate.of(1911, 1, 1);

                if (exif != null) {
                    float[] latLong = new float[2];
                    if(exif.getLatLong(latLong)) {
                        exif_latitude = latLong[0];
                        exif_longitude = latLong[1];
                    }

                    String dateStr = exif.getAttribute(ExifInterface.TAG_DATETIME);

                    if (dateStr != null) {
                        date = convertToDate(dateStr);
                    } else {
                        File f = new File(imagePath);
                        if (f != null) {
                            Long fileTime = f.lastModified();
                            date = Instant.ofEpochMilli(fileTime).atZone(ZoneId.systemDefault()).toLocalDate();
                        }
                    }

                }

                PictureRepo pictureRepo = new PictureRepo(imagePath,
                        date, exif_latitude, exif_longitude, false, false,
                        "label not detected yet", 0, 0.0, "", null);
                pictureRepos.add(pictureRepo);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (pictureRepos != null) {

            Collections.sort(pictureRepos, new Comparator<PictureRepo>() {
                @Override
                public int compare(PictureRepo o1, PictureRepo o2) {
                    LocalDate a = o1.getExifDate();
                    LocalDate b = o2.getExifDate();

                    if (a.isBefore(b)) {
                        return -1;
                    } else  if (a.isEqual(b)) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            });

        }
        return pictureRepos;
    }

    private static LocalDate convertToDate(String datetime) {
        if (datetime == null) return null;
        // Edwin change to LocalDate
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss");
        try {
            LocalDate localDate = LocalDate.parse(datetime, format);
            return localDate;
        } catch (DateTimeParseException e) {
            Log.e(TAG, e.getMessage());
            return null;
        }
    }
}
