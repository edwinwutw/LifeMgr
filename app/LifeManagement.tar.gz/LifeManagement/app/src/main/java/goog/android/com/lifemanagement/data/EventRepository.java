/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package goog.android.com.lifemanagement.data;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.content.ContentValues;
import android.util.Log;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.List;

import goog.android.com.lifemanagement.AppExecutors;
import goog.android.com.lifemanagement.CloudVision.CloudVisionApi;
import goog.android.com.lifemanagement.CloudVision.FeaturePolicy.FaceFeatureDetect;
import goog.android.com.lifemanagement.CloudVision.FeaturePolicy.LabelFeatureDetect;
import goog.android.com.lifemanagement.CloudVision.FeaturePolicy.ReceiptFeatureDetect;
import goog.android.com.lifemanagement.data.Classification.ClusteringBox;
import goog.android.com.lifemanagement.data.database.Event;
import goog.android.com.lifemanagement.data.database.EventDao;
import goog.android.com.lifemanagement.data.database.EventPictureJoin;
import goog.android.com.lifemanagement.data.database.EventPictureJoinDao;
import goog.android.com.lifemanagement.data.database.PictureRepo;
import goog.android.com.lifemanagement.data.database.PictureRepoDao;

/**
 * Handles data operations for life management event. Acts as a mediator between ClusteringBox
 * and Database}
 */

public class EventRepository {
    private static final String TAG = EventRepository.class.getSimpleName();

    // For Singleton instantiation
    private static final Object LOCK = new Object();
    private static EventRepository sInstance;

    private final EventDao mEventDao;
    private final PictureRepoDao mPictureRepoDao;
    private final EventPictureJoinDao mEventPictureJoinDao;

    private final ClusteringBox mClusteringBox;
    private final CloudVisionApi mCloudVisionApi;
    private final AppExecutors mExecutors;
    private final MutableLiveData<Boolean> mSendToCloudVision = new MutableLiveData<>();
    private final MutableLiveData<Boolean> mDoneHandleCloudVision = new MutableLiveData<>();

    private boolean mInitialized = false;

    private EventRepository(EventDao weatherDao,
                            PictureRepoDao pictureRepoDao,
                            EventPictureJoinDao eventPictureJoinDao,
                            ClusteringBox clusteringBox,
                            CloudVisionApi cloudVisionApi,
                            AppExecutors executors) {
        mEventDao = weatherDao;
        mPictureRepoDao = pictureRepoDao;
        mEventPictureJoinDao = eventPictureJoinDao;

        mClusteringBox = clusteringBox;
        mCloudVisionApi = cloudVisionApi;

        mExecutors = executors;

        LiveData<Event[]> eventLiveData = mClusteringBox.getEvents();
        eventLiveData.observeForever(newEventFromClassification -> {
            mExecutors.diskIO().execute(() -> {
                // TODO: enhance here
                Log.d(TAG, "delete Old events from databases");
                deleteEventPictureJoinData();
                deleteOldPictureData();
                deleteOldEventData();

                // insert new datas
                for (Event event : newEventFromClassification) {
                    // insert event
                    long eventId = mEventDao.insert(event);
                    // get if any pictures in event
                    List<PictureRepo> pictureRepos = event.getPictureRepos();
                    if (pictureRepos != null) {
                        // insert relation to joint table
                        for (PictureRepo pictureRepo : pictureRepos) {
                            // insert pictures
                            long pictureRepoId = mPictureRepoDao.insert(pictureRepo);
                            EventPictureJoin epj = new EventPictureJoin(eventId, pictureRepoId);
                            mEventPictureJoinDao.insert(epj);
                        }
                    }
                }
                Log.d(TAG, "New event values inserted");
                mSendToCloudVision.postValue(true);
            });
        });

        mSendToCloudVision.observeForever(signal -> {
            if (signal.booleanValue()) {
                sendToCloudVision();
            }
        });

        mDoneHandleCloudVision.observeForever(signal -> {
            if (signal.booleanValue()) {
                updateEventAfterDoneCloudVision();
            }
        });

        mCloudVisionApi.getCloudVisioAPIResult().observeForever(listContentValues -> {
            updateCloudVisionAPIResult(listContentValues);
        });
    }

    public synchronized static EventRepository getInstance(EventDao eventDao,
                                                           PictureRepoDao pictureRepoDao,
                                                           EventPictureJoinDao eventPictureJoinDao,
                                                           ClusteringBox classificationBox,
                                                           CloudVisionApi cloudVisionApi,
                                                           AppExecutors executors) {
        if (sInstance == null) {
            synchronized (LOCK) {
                sInstance = new EventRepository(eventDao, pictureRepoDao,
                        eventPictureJoinDao, classificationBox, cloudVisionApi, executors);
                Log.d(TAG, "Made new repository");
            }
        }
        return sInstance;
    }

    private void deleteOldEventData() {
        mEventDao.deleteAll();
    }

    private void deleteOldPictureData() {
        mPictureRepoDao.deleteAll();
    }

    private void deleteEventPictureJoinData() {
        mEventPictureJoinDao.deleteAll();
    }

    private synchronized void initializeData() {
        if (mInitialized)
            return;

        mInitialized = true;

        mExecutors.diskIO().execute(() -> {
            if (isClassificationNeeded()) {
                if (mClusteringBox != null) {
                    mClusteringBox.startClassify();
                }
            }
        });
    }

    private boolean isClassificationNeeded() {
        int count = mEventDao.countAllEvents();
        return (count <= 0); //TODO: use preference?
    }

    private void sendToCloudVision() {
        mExecutors.diskIO().execute(() -> {
            List<Event> events = mEventDao.getEventImmediately();
            HashMap<Integer, String> cloudVisionPictureMap = new HashMap<>();
            Log.d(TAG, "prepare event pictures before sendToCloudVision start");
            Log.d(TAG, "event number = " + events.size());
            int eventIdx = 0;
            int totalImagesCollected = 0;
            for (Event event : events) {
                List<PictureRepo> pictureRepos = getEventPicturesImmediately(event.getId());
                if (pictureRepos != null) {
                    for (PictureRepo pictureRepo : pictureRepos) {
                        if (false == pictureRepo.isSentToCloudVision()) {
                            cloudVisionPictureMap.put(new Integer(pictureRepo.getId()),
                                    pictureRepo.getImagePath());
                        }
                    }
                    Log.d(TAG, "event no. =" + eventIdx++ + ", acc images=" + pictureRepos.size());
                    totalImagesCollected += pictureRepos.size();
                }
            }
            Log.d(TAG, "total images collected = " + totalImagesCollected);
            Log.d(TAG, "prepare event pictures before sendToCloudVision end");

            if (!cloudVisionPictureMap.isEmpty() && mCloudVisionApi != null) {
                mCloudVisionApi.startCloudVisionService(cloudVisionPictureMap);
            }
        });
    }

    private void updateEventAfterDoneCloudVision() {
        mExecutors.diskIO().execute(() -> {
            if (mClusteringBox != null) {
                mClusteringBox.updateClassify(getAllPictures());
            }
        });
    }

    private void updateCloudVisionAPIResult(List<ContentValues> listContentValues) {
        mExecutors.diskIO().execute(() -> {
            if (listContentValues == null) return;

            Log.d(TAG, "updateCloudVisionAPIResult");
            for (ContentValues cvs : listContentValues) {
                // if has this key and value is true; then notify upper layer that all images
                // are done with CloudVision
                if (cvs.containsKey(CloudVisionApi.CONTENTVALUE_DONECLOUDVISION_KEY) &&
                    cvs.getAsBoolean(CloudVisionApi.CONTENTVALUE_DONECLOUDVISION_KEY).booleanValue()) {
                    mDoneHandleCloudVision.postValue(true);
                    Log.d(TAG, "notify done Handle CloudVision");
                    return;
                }

                int pictureId = -1;
                if (cvs.containsKey(CloudVisionApi.CONTENTVALUE_PICTUREID_KEY)) {
                    pictureId = cvs.getAsInteger(CloudVisionApi.CONTENTVALUE_PICTUREID_KEY).intValue();
                }
                if (pictureId != -1) {
                    PictureRepo pictureRepo = mPictureRepoDao.getPicture(pictureId);
                    if (pictureRepo != null) {
                        if (cvs.containsKey(CloudVisionApi.CONTENTVALUE_CLOUDVISION_KEY)) {
                            pictureRepo.setSentToCloudVision(cvs.getAsBoolean(
                                    CloudVisionApi.CONTENTVALUE_CLOUDVISION_KEY).booleanValue());
                        }
                        //label
                        if (cvs.containsKey(LabelFeatureDetect.CONTENTVALUE_KEY)) {
                            pictureRepo.setLabelDetected(cvs.getAsString(
                                    LabelFeatureDetect.CONTENTVALUE_KEY));
                        }
                        //faceno
                        if (cvs.containsKey(FaceFeatureDetect.CONTENTVALUE_KEY)) {
                            pictureRepo.setFaceNo(cvs.getAsInteger(
                                    FaceFeatureDetect.CONTENTVALUE_KEY).intValue());
                        }
                        //receipt
                        if (cvs.containsKey(ReceiptFeatureDetect.CONTENTVALUE_RECEIPT_KEY)) {
                            pictureRepo.setIsReceipt(cvs.getAsBoolean(
                                    ReceiptFeatureDetect.CONTENTVALUE_RECEIPT_KEY).booleanValue());
                        }
                        //receipt amount
                        if (cvs.containsKey(ReceiptFeatureDetect.CONTENTVALUE_AMOUNT_KEY)) {
                            pictureRepo.setReceiptAmount(cvs.getAsDouble(
                                    ReceiptFeatureDetect.CONTENTVALUE_AMOUNT_KEY).doubleValue());
                        }
                        //receipt no
                        if (cvs.containsKey(ReceiptFeatureDetect.CONTENTVALUE_RECEIPTNO_KEY)) {
                            pictureRepo.setReceiptNo(cvs.getAsString(
                                    ReceiptFeatureDetect.CONTENTVALUE_RECEIPTNO_KEY));
                        }
                        //receipt date
                        if (cvs.containsKey(ReceiptFeatureDetect.CONTENTVALUE_DATE_KEY)) {
                            try {
                                LocalDate localDate = LocalDate.parse(cvs.getAsString(
                                        ReceiptFeatureDetect.CONTENTVALUE_DATE_KEY));
                                pictureRepo.setReceiptDate(localDate);
                            } catch (DateTimeParseException e) {
                                // ignore, try next format
                                e.printStackTrace();
                            }
                        }
                        mPictureRepoDao.update(pictureRepo);
                    }
                }
            }
        });
    }

    /**
     * Database related operations
     **/
    public LiveData<List<Event>> getEvents() {
        initializeData();
        return mEventDao.getEvents();
    }

    public LiveData<Event> getEventById(final int eventId) {
        return mEventDao.getEventById(eventId);
    }

    public LiveData<List<PictureRepo>> getEventPictures(final int eventId) {
        return mEventPictureJoinDao.getEventPictures(eventId);
    }

    public List<PictureRepo> getEventPicturesImmediately(final int eventId) {
        return mEventPictureJoinDao.getEventPicturesImmediately(eventId);
    }

    public List<PictureRepo> getAllPictures() {
        return mPictureRepoDao.getAllPictures();
    }
}