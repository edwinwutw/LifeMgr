package goog.android.com.lifemanagement.utils;

import android.content.Context;

import goog.android.com.lifemanagement.AppExecutors;
import goog.android.com.lifemanagement.data.Classification.ClusteringBox;
import goog.android.com.lifemanagement.CloudVision.CloudVisionApi;
import goog.android.com.lifemanagement.data.EventRepository;
import goog.android.com.lifemanagement.data.database.LifeMgrDatabase;

/**
 * Provides static methods to inject the various classes
 */
public class InjectorUtils {

    public static EventRepository provideRepository(Context context) {
        LifeMgrDatabase database = LifeMgrDatabase.getInstance(context.getApplicationContext());
        AppExecutors executors = AppExecutors.getInstance();
        ClusteringBox clusteringBox = provideClusteringBox(context);
        CloudVisionApi cloudVisionApi = provideCloudVisionApi( context);
        return EventRepository.getInstance(database.getEventDao(),
                database.getPictureRepoDao(), database.getEventPictureJoinDao(),
                clusteringBox, cloudVisionApi, executors);
    }

    public static ClusteringBox provideClusteringBox(Context context) {
        AppExecutors executors = AppExecutors.getInstance();
        return ClusteringBox.getInstance(context.getApplicationContext(), executors);
    }

    public static CloudVisionApi provideCloudVisionApi(Context context) {
        AppExecutors executors = AppExecutors.getInstance();
        return CloudVisionApi.getInstance(context, executors);
    }
}