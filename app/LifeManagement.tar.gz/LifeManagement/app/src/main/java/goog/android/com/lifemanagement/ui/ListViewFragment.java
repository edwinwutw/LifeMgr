/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package goog.android.com.lifemanagement.ui;

import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import goog.android.com.lifemanagement.MainActivity;
import goog.android.com.lifemanagement.R;
import goog.android.com.lifemanagement.data.database.Event;
import goog.android.com.lifemanagement.databinding.ListFragmentBinding;
import goog.android.com.lifemanagement.utils.InjectorUtils;
import goog.android.com.lifemanagement.viewmodel.ListViewModel;

/**
 * A placeholder fragment containing a simple view.
 */
public class ListViewFragment extends Fragment {
    public static final String TAG = ListViewFragment.class.getSimpleName();

    private ListFragmentBinding mBinding;

    private ListAdapter mListAdapter;

    private ListViewModel mListViewModel;

    public ListViewFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.list_fragment, container,
                false);

        mListAdapter = new ListAdapter(mItemClickCallback);

        mBinding.eventsList.setHasFixedSize(true);
        mBinding.eventsList.setItemViewCacheSize(20);
        mBinding.eventsList.setDrawingCacheEnabled(true);
        mBinding.eventsList.setAdapter(mListAdapter);

        return mBinding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        ListViewModel.ListViewModelFactory factory = InjectorUtils.provideListViewModelFactory(
                getActivity().getApplicationContext());
        mListViewModel = ViewModelProviders.of(this, factory).get(ListViewModel.class);

        subscribeUi(mListViewModel);
    }

    private void subscribeUi(ListViewModel viewModel) {
        // Update the list when the data changes
        viewModel.getEvents().observe(this, this::updateEventList);
    }

    private void updateEventList(List<Event> myEvents) {
        mListAdapter.setEventList(myEvents);

        if (myEvents != null && myEvents.size() != 0) mBinding.setIsLoading(false);
        else mBinding.setIsLoading(true);
        // espresso does not know how to wait for data binding's loop so we execute changes
        // sync.
        mBinding.executePendingBindings();
    }

    private final ItemClickCallback mItemClickCallback = new ItemClickCallback() {
        @Override
        public boolean onLongClick(Event event) {
            return false;
        }

        @Override
        public void onClick(Event event) {
            ((MainActivity) getActivity()).show(event);
        }

    };
}
