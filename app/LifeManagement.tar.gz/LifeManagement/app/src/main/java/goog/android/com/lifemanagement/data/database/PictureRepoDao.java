package goog.android.com.lifemanagement.data.database;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;


/**
 * Created by edwinwu on 2018/3/27.
 */
@Dao
public interface PictureRepoDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(PictureRepo pictureRepo);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(PictureRepo... pictureRepos);

    @Update
    void update(PictureRepo pictureRepo);

    @Update
    void update(PictureRepo... pictureRepos);

    @Delete
    void delete(PictureRepo... pictureRepos);

    @Query("DELETE FROM picturerepo")
    void deleteAll();

    @Query("SELECT * FROM picturerepo")
    List<PictureRepo> getAllPictures();

    @Query("SELECT * FROM picturerepo WHERE id = :id")
    PictureRepo getPicture(int id);


}
