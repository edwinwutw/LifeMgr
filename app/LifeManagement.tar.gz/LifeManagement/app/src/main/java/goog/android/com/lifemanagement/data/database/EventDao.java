package goog.android.com.lifemanagement.data.database;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.time.LocalDate;
import java.util.List;

/**
 * Created by edwinwu on 2018/3/27.
 */
@Dao
public interface EventDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(Event event);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Event... event);

    @Update
    void update(Event... event);

    @Delete
    void delete(Event... event);

    @Query("DELETE FROM event")
    void deleteAll();

    @Query("SELECT * FROM event")
    LiveData<List<Event>> getEvents();

    @Query("SELECT * FROM event where id = :eventId")
    LiveData<Event> getEventById(int eventId);

    @Query("SELECT * FROM event")
    List<Event> getEventImmediately();

    @Query("SELECT * FROM event WHERE date = :localDate")
    LiveData<Event> getEventByDate(LocalDate localDate);

    @Query("SELECT COUNT(id) FROM event")
    int countAllEvents();
}